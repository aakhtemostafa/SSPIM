function out = y_grating(Y,a)
out = (a.*Y);